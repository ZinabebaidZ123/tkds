export interface Classes {
  "tox-dialog__disable-scroll": string;
  "tox-fullscreen": string;
  "tox": string;
  "tox-tinymce": string;
  "tox-statusbar__resize-handle": string;
  "tox-shadowhost": string;
  "tox-tinymce-aux": string;
};
